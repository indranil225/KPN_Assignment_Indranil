declare module "@salesforce/resourceUrl/boats" {
    var boats: string;
    export default boats;
}