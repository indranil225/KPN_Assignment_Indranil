declare module "@salesforce/resourceUrl/lts_mochaBootJs" {
    var lts_mochaBootJs: string;
    export default lts_mochaBootJs;
}