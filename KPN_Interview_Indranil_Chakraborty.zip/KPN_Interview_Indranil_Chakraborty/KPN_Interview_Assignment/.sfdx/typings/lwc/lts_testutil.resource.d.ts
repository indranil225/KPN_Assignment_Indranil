declare module "@salesforce/resourceUrl/lts_testutil" {
    var lts_testutil: string;
    export default lts_testutil;
}