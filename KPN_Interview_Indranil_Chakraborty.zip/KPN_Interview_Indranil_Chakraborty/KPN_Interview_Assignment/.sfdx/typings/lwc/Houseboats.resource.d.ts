declare module "@salesforce/resourceUrl/Houseboats" {
    var Houseboats: string;
    export default Houseboats;
}