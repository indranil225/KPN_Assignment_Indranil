declare module "@salesforce/resourceUrl/Mock_Data" {
    var Mock_Data: string;
    export default Mock_Data;
}