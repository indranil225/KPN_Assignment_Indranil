declare module "@salesforce/apex/egServerSideActionController.searchAccounts" {
  export default function searchAccounts(param: {searchString: any}): Promise<any>;
}
