declare module "@salesforce/apex/OrderHandler.getProductsRelatedToOrder" {
  export default function getProductsRelatedToOrder(param: {recId: any}): Promise<any>;
}
declare module "@salesforce/apex/OrderHandler.getOrderDetails" {
  export default function getOrderDetails(param: {recId: any}): Promise<any>;
}
declare module "@salesforce/apex/OrderHandler.getAvailableProducts" {
  export default function getAvailableProducts(param: {recId: any}): Promise<any>;
}
declare module "@salesforce/apex/OrderHandler.addOrderItem" {
  export default function addOrderItem(param: {orderId: any, productId: any, quantity: any, unitPrice: any, pricebookEntryId: any}): Promise<any>;
}
declare module "@salesforce/apex/OrderHandler.callExternalServiceToConfirmOrder" {
  export default function callExternalServiceToConfirmOrder(param: {recId: any}): Promise<any>;
}
