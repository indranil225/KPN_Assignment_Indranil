declare module "@salesforce/apex/OrderController.getOrderItems" {
  export default function getOrderItems(param: {recId: any}): Promise<any>;
}
declare module "@salesforce/apex/OrderController.getOrderDetails" {
  export default function getOrderDetails(param: {recId: any}): Promise<any>;
}
declare module "@salesforce/apex/OrderController.getAvailableProductList" {
  export default function getAvailableProductList(param: {recId: any}): Promise<any>;
}
declare module "@salesforce/apex/OrderController.addOrderItem" {
  export default function addOrderItem(param: {orderId: any, productId: any, quantity: any, unitPrice: any, pricebookEntryId: any}): Promise<any>;
}
declare module "@salesforce/apex/OrderController.confirmOrder" {
  export default function confirmOrder(param: {recId: any}): Promise<any>;
}
