declare module "@salesforce/resourceUrl/lts_chai" {
    var lts_chai: string;
    export default lts_chai;
}