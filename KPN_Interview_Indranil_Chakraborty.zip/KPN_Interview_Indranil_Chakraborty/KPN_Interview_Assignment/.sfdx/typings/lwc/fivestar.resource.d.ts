declare module "@salesforce/resourceUrl/fivestar" {
    var fivestar: string;
    export default fivestar;
}