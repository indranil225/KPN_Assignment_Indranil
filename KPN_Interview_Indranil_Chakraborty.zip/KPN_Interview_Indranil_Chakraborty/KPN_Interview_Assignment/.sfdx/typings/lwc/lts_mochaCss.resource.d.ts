declare module "@salesforce/resourceUrl/lts_mochaCss" {
    var lts_mochaCss: string;
    export default lts_mochaCss;
}