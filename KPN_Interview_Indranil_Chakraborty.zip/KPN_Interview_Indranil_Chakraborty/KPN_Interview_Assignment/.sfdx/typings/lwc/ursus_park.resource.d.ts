declare module "@salesforce/resourceUrl/ursus_park" {
    var ursus_park: string;
    export default ursus_park;
}