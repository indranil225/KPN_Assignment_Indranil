declare module "@salesforce/resourceUrl/lts_mochaJs" {
    var lts_mochaJs: string;
    export default lts_mochaJs;
}