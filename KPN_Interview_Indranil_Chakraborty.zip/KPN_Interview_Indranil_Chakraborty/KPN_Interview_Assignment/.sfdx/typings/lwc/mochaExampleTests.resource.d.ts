declare module "@salesforce/resourceUrl/mochaExampleTests" {
    var mochaExampleTests: string;
    export default mochaExampleTests;
}