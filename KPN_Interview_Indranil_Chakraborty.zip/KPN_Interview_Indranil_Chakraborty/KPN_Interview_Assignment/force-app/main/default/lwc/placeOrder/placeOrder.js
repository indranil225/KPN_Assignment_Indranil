import { LightningElement, api } from 'lwc';

export default class PlaceOrder extends LightningElement {
    @api recordId;

    //refresh order items list
    refreshComp(){
        this.template.querySelector('c-order-item-list').reloadComp(); 
    }
}